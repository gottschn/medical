<header>
        <nav class="nav__bar">
            <div class="con__tent">
                <div class="logo">
                    <a href="<?php echo e(route('home')); ?>"><img src="img/LogoPNG.png" alt="CEF Medical" width="220px"></a>

                </div>

                <ul class="menu__list">
                    <div class="icon cancel-btn">
                        <i class="uil uil-multiply"></i>
                    </div>
                    <li><a href="<?php echo e(route('preCredito')); ?>">Créditos</a></li>
                    <li><a href="<?php echo e(route('redPrestadores')); ?>">Prestadores</a></li>
                    <li><a href="<?php echo e(route('aboutus')); ?>">Nosotros</a></li>
                    <li><a href="<?php echo e(route('pacientes')); ?>">Pacientes</a></li>
                    <?php if(isset(Auth::user()->name)): ?>
                        <form action="<?php echo e(route('logout')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <li><button href=""><?php echo e(Auth::user()->name); ?></button></li>
                        </form>
                    <?php else: ?>
                        <li><a class="nav-link" href="#" data-toggle="modal" data-target="#signupModal">Suscribite</a></li>
                    <?php endif; ?>

                </ul>

                <div class="btn-group" role="group" aria-label="Basic outlined example" id="botones">
                </div>
                <div class="icon menu-btn">
                    <i class="uil uil-bars"></i>
                </div>
            </div>
        </nav>
    </header><?php /**PATH C:\xampp\htdocs\laravel-socialite\resources\views/layouts/header.blade.php ENDPATH**/ ?>