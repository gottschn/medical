<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header col-md-6 offset-md-3"><?php echo e(__('Iniciar Sesíon')); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <div class="col-md-6 offset-md-3">
                                <a href="<?php echo e(route('login.google')); ?>" class="btn btn-danger btn-block">Login with Google</a>
                                <a href="<?php echo e(route('login.facebook')); ?>" class="btn btn-primary btn-block">Login with Facebook</a>
                            </div>
                        </div>
             
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-socialite\resources\views/auth/login.blade.php ENDPATH**/ ?>